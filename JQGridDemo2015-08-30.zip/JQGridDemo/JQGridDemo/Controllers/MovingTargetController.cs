﻿using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Mvc;
using Trirand.Web.Mvc;

namespace JQGridDemo.Controllers
{
    public class MovingTargetController : Controller
    {
        public ActionResult AnEvolvingTool()
        {
            return View();
        }
    }
}